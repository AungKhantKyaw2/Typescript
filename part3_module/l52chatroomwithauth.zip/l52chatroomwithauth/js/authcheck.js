import {Authorize} from "./Authorize.js";

const authObj = new Authorize();
authObj.isLoggedIn();